<?php
	$metas = array(
		"fiel" => array(
			"title" => "¿Fiel o infiel?",
			"description" => "¡Todos quieren a alguien como tú! Tu fidelidad no se cuestiona. Es más, ni los del Atlas esperando 100 años por un título te superan",
			"image" => "images/respuestas/fiel.jpg" 
		),
		"infiel" => array(
			"title" => "¿Fiel o infiel?",
			"description" => "Te conocen como el Zlatan de tu colonia y no precisamente por jugar como él. Sólo sabes estar de equipo en equipo y así como hoy puede estar ganando “tu” equipo, mañana ya los cambiaste",
			"image" => "images/respuestas/infiel.jpg" 
		)
	);